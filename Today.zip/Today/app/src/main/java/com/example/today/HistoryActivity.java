package com.example.today;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.today.base.BaseActivity;
import com.example.today.base.HistoryBean;
import com.example.today.base.TodaysUrl;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

public class HistoryActivity extends BaseActivity {
    TextView title, content;
    ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        this.title = findViewById(R.id.contentTitle);
        this.content = findViewById(R.id.contents);
        this.image = findViewById(R.id.contentImage);

        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        Log.d("id", id);
        String url = TodaysUrl.getTodayUrlById("1.0", id);
        this.loadData(url);
    }

    @Override
    public void onSuccess(String result) {
        HistoryBean historyBean = new Gson().fromJson(result, HistoryBean.class);
        HistoryBean.ResultBean resultBean = historyBean.getResult().get(0);
        this.title.setText(resultBean.getTitle());
        this.content.setText(resultBean.getDes());
        String picUrl = resultBean.getPic();
        if (!picUrl.isEmpty()){
            this.image.setVisibility(View.VISIBLE);
            Picasso.with(this).load(picUrl).into(this.image);
        }else {
            this.image.setVisibility(View.GONE);
        }
    }
}
